<?php

header("location: ../html/page_enregistrement_pathologie1.php");

?>