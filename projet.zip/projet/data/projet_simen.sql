-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: May 25, 2021 at 07:51 AM
-- Server version: 10.4.17-MariaDB
-- PHP Version: 8.0.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `projet_simen`
--

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(200) NOT NULL,
  `nom` varchar(200) NOT NULL,
  `prenom` varchar(200) NOT NULL,
  `email` varchar(200) NOT NULL,
  `mdp` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `nom`, `prenom`, `email`, `mdp`) VALUES
(8, 'TALLA', 'CYRIL', 'Cyrilngueloh1@gmail.com', '$2y$10$SpIFzbYIcvDcvy57Q3iEHu8NyXHIl3/2vm8.WkO2ihAUbO06illgC'),
(13, 'TALLA', 'CYRIL', 'ngueloh1@gmail.com', '$2y$10$/gysjswzfzCwaN6iGl/foOAled9P3nPR3tfKqI3UUggtmALQW7F3G'),
(14, 'TALLA', 'CYRIL', 'gueloh1@gmail.com', '$2y$10$m/EQMAcaT4Nw0fGNWB.EreaYJc7vX7rzIDGv6V5dnaJF/95GsTsvu'),
(16, 'TALLA', 'CYRIL', 'rtgueloh1@gmail.com', '$2y$10$aE0rRk0RlS3NA1R/Ozb4kOjzFjMQjHPSHTVVS3jAnLDH.nftKfLVm'),
(17, 'JAVA', 'PHP', 'Cyrilngueloh3@gmail.com', '$2y$10$oE99dybWKoqNWcHxZn.FWOcN1mygJ3ipAkKy5ddhG3WktGQe9lycq'),
(18, 'JAVA', 'PHP', 'Cyrilngueloh4@gmail.com', '$2y$10$433QJ0Uqn02cF/QTqGW4VejdqGhSSY8nVjmXlZmH1nghP3ycr1vW.'),
(19, 'valeur par defaut', 'valeur par defaut', 'valeur par defaut', '$2y$10$FGaynsrGc9SJmQxDIQwO7OaIW79b9DtHgTO09pyyOvZIaAiIEa31i'),
(20, 'ccccc', 'ccccccc', 'cyril@gmail.com', '$2y$10$Hjo4aX8ZZGCyvAECvte7I.LK8ADFLlhWc09lJEDwKxYKt.QOVeDQ.'),
(32, 'googli', 'goll', 'cyriux@gmail.com', '$2y$10$.WSXcR5M9lPnEWoWdsBfU.rOh4YQD125DI/XXLSCq8uhAKDp61Swi'),
(43, '', '', 'cyti@gmail.com', '$2y$10$xVvueWLNSYGm/YLTzTIYkeTSvX00WcuQ0MWheeC8kwpMlgkH5pumm'),
(44, 'hhgfgjjf', 'jdhdgggf', 'hfhfhf@gmail.com', '$2y$10$0o8Ab5KbdxO.ZIBemjaR8.Dluggxmb0GiKFL6GyLgGTXKKzEUTz76'),
(45, 'ggghhh', 'ffdddddffghh', 'fgfcgg@gmail.com', '$2y$10$wwuARqNEU8FRGf4orffWSelWYek4H49Eh/zr4GEIWaFCRZprcVRkG'),
(46, 'ddddddd', 'dddddddddd', 'ddddddd@gmail.com', '$2y$10$GCHvrLMGtpea630K9938hO1dnW9Xj2VACgoVHkUVP8iwXmSpC3xTe'),
(47, 'jojo', 'JOJO', 'jojo@gmail.com', '$2y$10$v24tmEuaqwYhdPTkRN9OZOG4AhRjXcN6OlCrgh3OaPmgx.K8mWdjO'),
(48, 'jojo', 'jojo', 'Jores@gmail.com', '$2y$10$r/xl009AA3xpDiTQYzC86..xDgPxO5yKi7YSaFkEJrCHT5S.RfSKa'),
(54, 'jojo', 'JOJO', 'jojrito@gmail.com', '$2y$10$5xTtzA0USOtSfbKlv38h6.FBISPtqOwglefZhQNp/hsjVvZ.gXwK6');

-- --------------------------------------------------------

--
-- Table structure for table `visite`
--

CREATE TABLE `visite` (
  `id` int(11) NOT NULL,
  `email` varchar(100) NOT NULL,
  `lieu_visite` varchar(200) NOT NULL,
  `numero_civique` int(11) NOT NULL,
  `rue` varchar(100) NOT NULL,
  `ville` varchar(100) NOT NULL,
  `province` varchar(100) NOT NULL,
  `date_arrive` datetime NOT NULL,
  `date_depart` datetime NOT NULL,
  `pathologie` varchar(50) NOT NULL DEFAULT 'non',
  `symptome` varchar(50) NOT NULL DEFAULT 'non',
  `duree` varchar(50) NOT NULL DEFAULT 'aucun'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `visite`
--

INSERT INTO `visite` (`id`, `email`, `lieu_visite`, `numero_civique`, `rue`, `ville`, `province`, `date_arrive`, `date_depart`, `pathologie`, `symptome`, `duree`) VALUES
(4, 'default', 'default', 15, 'default', '', 'default', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '', '', ''),
(11, 'emaicdccl', 'alberccccta', 12455, 'cornvvvvvier', '', 'provinvvvvvce', '2021-05-12 00:00:00', '2021-05-12 00:00:00', '', '', ''),
(24, 'cyrilngueloh3@gmail.com', 'quebecois', 456, 'surnois', 'albertain', 'Alberta', '2021-05-04 00:37:00', '2021-05-12 04:37:00', '', '', ''),
(25, 'cyrilngueloh3@gmail.com', 'ontarion', 789456, 'bavarois', 'ontari', 'Ontarion', '2021-05-04 01:42:00', '2021-05-05 02:42:00', '', '', ''),
(26, 'cyrilngueloh3@gmail.com', 'montreal', 123, 'ccccccc', 'ffffff', 'Quebec', '2021-04-28 02:51:00', '2021-05-04 02:51:00', '', '', ''),
(27, '', 'fffffff', 1236, 'dddd', 'quebec', 'yhghfg', '2021-05-26 04:16:00', '2021-05-07 04:16:00', '', '', ''),
(28, 'cyrilngueloh3@gmail.com', 'fffffff', 67507, 'ccccccc', 'ffffff', 'Alberta', '2021-04-26 04:53:00', '2021-05-04 05:53:00', 'oui', 'une_semaine', ''),
(29, 'cyrilngueloh3@gmail.com', 'fffffff', 75369, 'ccccccc', 'ffffff', 'Nouvelle Colombie', '2021-05-04 03:57:00', '2021-04-29 04:57:00', 'oui', 'non', ' une semaine'),
(30, 'email', 'alberta', 125, 'cornier', 'Montreal', 'province', '2021-05-12 15:21:56', '2021-05-12 15:21:56', '', '', ''),
(31, 'email', 'alberta', 125, 'cornier', 'Montreal', 'province', '2021-05-12 15:21:56', '2021-05-12 15:21:56', '', '', ''),
(32, 'email', 'alberta', 125, 'cornier', 'Montreal', 'province', '2021-05-12 15:21:56', '2021-05-12 15:21:56', ' ', ' ', ' '),
(33, 'email', 'alberta', 125, 'cornier', 'Montreal', 'province', '2021-05-12 15:21:56', '2021-05-12 15:21:56', ' ', ' ', ' '),
(34, 'email', 'alberta', 125, 'cornier', 'Montreal', 'province', '2021-05-12 15:21:56', '2021-05-12 15:21:56', ' ', ' ', ' '),
(35, 'email', 'alberta', 125, 'cornier', 'Montreal', 'province', '2021-05-12 15:21:56', '2021-05-12 15:21:56', ' ', ' ', ' '),
(36, 'email', 'alberta', 125, 'cornier', 'Montreal', 'province', '2021-05-12 15:21:56', '2021-05-12 15:21:56', ' ', ' ', ' '),
(37, 'email', 'alberta', 125, 'cornier', 'Montreal', 'province', '2021-05-12 15:21:56', '2021-05-12 15:21:56', ' ', ' ', ' '),
(38, 'email', 'alberta', 125, 'cornier', 'Montreal', 'province', '2021-05-12 15:21:56', '2021-05-12 15:21:56', ' ', ' ', ' '),
(39, 'email', 'alberta', 125, 'cornier', 'Montreal', 'province', '2021-05-12 15:21:56', '2021-05-12 15:21:56', ' ', ' ', ' '),
(40, 'email', 'alberta', 125, 'cornier', 'Montreal', 'province', '2021-05-12 15:21:56', '2021-05-12 15:21:56', ' ', ' ', ' '),
(41, 'email', 'alberta', 125, 'cornier', 'Montreal', 'province', '2021-05-12 15:21:56', '2021-05-12 15:21:56', ' ', ' ', ' '),
(42, 'email', 'alberta', 125, 'cornier', 'Montreal', 'province', '2021-05-12 15:21:56', '2021-05-12 15:21:56', ' ', ' ', ' '),
(43, 'email', 'alberta', 125, 'cornier', 'Montreal', 'province', '2021-05-12 15:21:56', '2021-05-12 15:21:56', ' ', ' ', ' '),
(44, 'email', 'alberta', 125, 'cornier', 'Montreal', 'province', '2021-05-12 15:21:56', '2021-05-12 15:21:56', ' ', ' ', ' '),
(45, 'email', 'alberta', 125, 'cornier', 'Montreal', 'province', '2021-05-12 15:21:56', '2021-05-12 15:21:56', ' ', ' ', ' '),
(46, 'email', 'alberta', 125, 'cornier', 'Montreal', 'province', '2021-05-12 15:21:56', '2021-05-12 15:21:56', ' ', ' ', ' '),
(47, 'email', 'alberta', 125, 'cornier', 'Montreal', 'province', '2021-05-12 15:21:56', '2021-05-12 15:21:56', ' ', ' ', ' '),
(48, 'email', 'alberta', 125, 'cornier', 'Montreal', 'province', '2021-05-12 15:21:56', '2021-05-12 15:21:56', ' ', ' ', ' '),
(49, 'email', 'alberta', 125, 'cornier', 'Montreal', 'province', '2021-05-12 15:21:56', '2021-05-12 15:21:56', ' ', ' ', ' '),
(50, 'email', 'alberta', 125, 'cornier', 'Montreal', 'province', '2021-05-12 15:21:56', '2021-05-12 15:21:56', ' ', ' ', ' '),
(51, 'cyrilngueloh3@gmail.com', 'montreal', 123654, 'vvvv', 'ccccc', 'Nouvelle Colombie', '2021-04-28 00:48:00', '2021-05-13 02:44:00', 'oui', 'non', ' une semaine'),
(52, 'cyrilngueloh3@gmail.com', 'montreal', 123654, 'vvvv', 'ccccc', 'Nouvelle Colombie', '2021-04-28 00:48:00', '2021-05-13 02:44:00', 'oui', 'non', ' une semaine'),
(53, 'cyrilngueloh3@gmail.com', 'montreal', 123654, 'vvvv', 'ccccc', 'Nouvelle Colombie', '2021-04-28 00:48:00', '2021-05-13 02:44:00', 'oui', 'non', ' une semaine'),
(54, 'cyrilngueloh3@gmail.com', 'fffffff', 7894123, 'ccccccc', 'ccccc', 'Alberta', '2021-05-04 03:05:00', '2021-05-19 03:05:00', 'oui', 'oui', ' une semaine');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `visite`
--
ALTER TABLE `visite`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(200) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=55;

--
-- AUTO_INCREMENT for table `visite`
--
ALTER TABLE `visite`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=55;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
