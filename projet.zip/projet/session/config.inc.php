<?php

/* 
 * Configuration du système
 */

// Configuration de la base de données

  //  $DNS = "mysql:host=localhost;dbname=projet_simen";
   // $USAGER = "root";
   // $MDP = "";

define("DNS", 'mysql:dbname=projet_simen;host=localhost');
define("USAGER", 'root');
define("MDP", '');

  
?>